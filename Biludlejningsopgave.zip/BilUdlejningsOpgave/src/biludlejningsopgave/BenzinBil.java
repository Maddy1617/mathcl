package biludlejningsopgave;

public class BenzinBil extends Bil {
   private int oktantal;
   private int kmPrL;

    public BenzinBil(int oktantal, int kmPrL, String regNr, String mærke, String model, int årgang, int antalDøre) {
        super(regNr, mærke, model, årgang, antalDøre);
        this.oktantal = oktantal;
        this.kmPrL = kmPrL;
    }

    public int getOktantal() {
        return oktantal;
    }

    public void setOktantal(int oktantal) {
        this.oktantal = oktantal;
    }

    public int getKmPrL() {
        return kmPrL;
    }

    public void setKmPrL(int kmPrL) {
        this.kmPrL = kmPrL;
    }
    @Override
    public double beregnGrønEjerafgift() {
     double ejerafgift = 0;
     if (kmPrL >= 20 && kmPrL < 50) {
         ejerafgift = 330;
     } else if (kmPrL >= 15 && kmPrL < 20) {
         ejerafgift = 1050;
     } else if (kmPrL >= 10 && kmPrL < 15) {
         ejerafgift = 2340;
     } else if (kmPrL >= 5 && kmPrL < 10) {
         ejerafgift = 5500;
     } else if (kmPrL < 5) {
         ejerafgift = 10470;
     } return ejerafgift;
    }
    @Override
    public String toString() {
        return "Benzinbil:\n" + "Registreringsnummer: " + getRegNr() + "\nMærke: " + getMærke()+"\nModel: "
                + getModel() + "\nÅrgang: "+getÅrgang()+"\nAntal døre: "+getAntalDøre()+"\nOktantal: " + oktantal + "\nKilometer pr liter: "+kmPrL+"/L\n" +"Grønejerafgift: "+beregnGrønEjerafgift()+"kr\n";
    }
    
   
}
