package biludlejningsopgave;

/* @author Mathias Noe Clausen
*/
public class Main {

    public static void main(String[] args) {
        Bil bil1 = new BenzinBil(95,20,"BM97084","Volvo","V40",2004,5);
        Bil bil2 = new DieselBil(true,10,"CM17053","Fiat","Punto",2007,3);
        Bil bil3 = new ElBil(75,386,194,"AC19063","Tesla","Model 3",2018,5);
        Garage garage = new Garage();
        garage.tilføjBil(bil1);
        garage.tilføjBil(bil2);
        garage.tilføjBil(bil3);
        System.out.println(garage.toString());
        System.out.println(garage.beregnGrønAfgiftForBilpark()+"kr");
        
    }
    
}
