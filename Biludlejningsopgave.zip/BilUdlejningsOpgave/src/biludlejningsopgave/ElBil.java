package biludlejningsopgave;

public class ElBil extends Bil {
    private int batterikapacitetKWh;
    private int maxKm;
    private int whPrKm;

    public ElBil(int batterikapacitetKWh, int maxKm, int whPrKm, String regNr, String mærke, String model, int årgang, int antalDøre) {
        super(regNr, mærke, model, årgang, antalDøre);
        this.batterikapacitetKWh = batterikapacitetKWh;
        this.maxKm = maxKm;
        this.whPrKm = whPrKm;
    }

    public int getBatterikapacitetKWh() {
        return batterikapacitetKWh;
    }

    public void setBatterikapacitetKWh(int batterikapacitetKWh) {
        this.batterikapacitetKWh = batterikapacitetKWh;
    }

    public int getMaxKm() {
        return maxKm;
    }

    public void setMaxKm(int maxKm) {
        this.maxKm = maxKm;
    }

    public int getWhPrKm() {
        return whPrKm;
    }

    public void setWhPrKm(int whPrKm) {
        this.whPrKm = whPrKm;
    }
    @Override
    public double beregnGrønEjerafgift() {
         double ejerafgift = 0;
         double omregner;
         omregner = 100/(whPrKm/91.25);
     if (omregner >= 20 && omregner < 50) {
         ejerafgift = 330;
     } else if (omregner >= 15 && omregner < 20) {
         ejerafgift = 1050;
     } else if (omregner >= 10 && omregner < 15) {
         ejerafgift = 2340;
     } else if (omregner >= 5 && omregner < 10) {
         ejerafgift = 5500;
     } else if (omregner < 5) {
         ejerafgift = 10470;
     } return ejerafgift;
    }
    @Override
    public String toString() {
        return "Elbil:\n" + "Registreringsnummer: " + getRegNr() + "\nMærke: " + getMærke()+"\nModel: "
                + getModel() + "\nÅrgang: "+getÅrgang()+"\nAntal døre: "+getAntalDøre()+"\nBatterikapacitet: " + batterikapacitetKWh +"kwH"+"\nMax distance: "+maxKm+"km"+"\nwhPrKm: "+whPrKm+"wh"+"\nGrønejerafgift: "+beregnGrønEjerafgift()+"kr\n";
    }
    
    
}
