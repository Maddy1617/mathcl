package biludlejningsopgave;

public class DieselBil extends Bil {

    private boolean harPartikelfilter;
    private int kmPrL;

    public DieselBil(boolean harPartikelfilter, int kmPrL, String regNr, String mærke, String model, int årgang, int antalDøre) {
        super(regNr, mærke, model, årgang, antalDøre);
        this.harPartikelfilter = harPartikelfilter;
        this.kmPrL = kmPrL;
    }

    public boolean isHarPartikelfilter() {
        return harPartikelfilter;
    }

    public void setHarPartikelfilter(boolean harPartikelfilter) {
        this.harPartikelfilter = harPartikelfilter;
    }

    public int getKmPrL() {
        return kmPrL;
    }

    public void setKmPrL(int kmPrL) {
        this.kmPrL = kmPrL;
    }

    public String oversætBoolean(boolean bool) {
        String værdi = null;
        if (bool) {
            værdi = "Ja";
        } else {
            værdi = "Nej";
        } return værdi;
    }
    @Override
    public double beregnGrønEjerafgift() {
         double ejerafgift = 0;
         int partikelUdledningsafgift = 1000;
     if (kmPrL >= 20 && kmPrL < 50) {
         ejerafgift = 330 + 130;
     } else if (kmPrL >= 15 && kmPrL < 20) {
         ejerafgift = 1050 + 1390;
     } else if (kmPrL >= 10 && kmPrL < 15) {
         ejerafgift = 2340 + 1850;
     } else if (kmPrL >= 5 && kmPrL < 10) {
         ejerafgift = 5500 + 2770;
     } else if (kmPrL < 5) {
         ejerafgift = 10470 + 15260;
         
     } if (!harPartikelfilter) {
         ejerafgift += partikelUdledningsafgift;
     }
     return ejerafgift;
    }
        @Override
        public String toString
        
            () {
        return "Dieselbil:\n" + "Registreringsnummer: " + getRegNr() + "\nMærke: " + getMærke() + "\nModel: "
                    + getModel() + "\nÅrgang: " + getÅrgang() + "\nAntal døre: " + getAntalDøre() + "\nPartikelfilter: " + oversætBoolean(harPartikelfilter) + "\nKilometer pr liter: " + kmPrL + "/L\n" +"Grønejerafgift: "+beregnGrønEjerafgift()+"kr\n";
        }

    }

