package biludlejningsopgave;

import java.util.ArrayList;

public class Garage {

    ArrayList<Bil> bilGarage = new ArrayList();

    public void tilføjBil(Bil bil) {
        bilGarage.add(bil);
    }

    @Override
    public String toString() {
        String biler = "";
        int antalBiler = 0;
        for (Bil enBil : bilGarage) {
            biler += enBil.toString() + "\n";
            antalBiler += 1;
        } System.out.println("Antal biler i garagen: "+antalBiler+"\n\n");
        return biler;
    }

    public double beregnGrønAfgiftForBilpark() {
        double samletAfgift = 0;
        for(Bil enBil : bilGarage) {
            samletAfgift += enBil.beregnGrønEjerafgift();            
        } System.out.println("Den samlede grønne afgift for garagen: ");
        return samletAfgift;
    }
    
}
